<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome<?php echo ' "'. $userRow['firstname'] . '"'; ?></title>
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"  />
<link rel="stylesheet" href="style.css" type="text/css" />
</head>
<body>

	<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
      <div class="container-fluid">
        <div class="navbar-header">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#"></a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="navbar">
          <ul class="nav navbar-nav">
            <li><a href="#"><strong>ADIDAS</strong></a></li>
            <li><a href="#"></a></li>
      
                    <form action="search.php" class="navbar-form navbar-right" method="POST" enctype="multipart/form-data">
                          <div class="input-group">
                             <input type="text" placeholder="Search User" class="form-control" name="query">
                             <div class="input-group-btn">
                                 <button class="btn btn-default">
                                    <span class="glyphicon glyphicon-search"></span>
                                 </button>
                             </div>
                         </div>
                        </form>
          </ul>

                <ul class="nav navbar-nav navbar-right">

                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
            <span class="glyphicon glyphicon-user"></span>&nbsp;Hi <?php echo $userRow['firstname']; ?>&nbsp;<span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="logout.php?logout"><span class="glyphicon glyphicon-log-out"></span>Sign Out</a></li>
                        </ul>
                    </li>
                </ul>
        </div><!-- /.navbar-collapse -->
      </div><!-- /.container-fluid -->
    </nav>

    <div id="wrapper">
    <div class="container">
        <div class="page-header">
        <br>
        <h2><center><b>ADIDAS ADMIN</b></center></h2>
        </div>
        
<div class="container">

	<div id="login-form">
    <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" autocomplete="off">

    	<div class="col-md-12">

        	<!-- Main content -->

              <div class="panel panel-default">
              <div class="panel-body">
               
              </div>
                

</div>

</body>
</html>