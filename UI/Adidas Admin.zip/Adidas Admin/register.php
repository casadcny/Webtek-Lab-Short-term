<?php
	ob_start();
	session_start();
	if( isset($_SESSION['user'])!="" ){
		header("Location: home.php");
	}
	include_once 'connect.php';

	$error = false;

	if ( isset($_POST['btn-signup']) ) {
		
		$firstname = trim($_POST['firstname']);
		$firstname = strip_tags($firstname);

		$lastname = trim($_POST['lastname']);
		$lastname = strip_tags($lastname);
	
		$username = trim($_POST['username']);
		$username = strip_tags($username);
		
		$idno = trim($_POST['idno']);
		$idno = strip_tags($idno);

		$password = trim($_POST['password']);
		$password = strip_tags($password);

	


		// if there's no error, continue to signup
		if( !$error ) {

			$query = "INSERT INTO user(firstname, lastname, username, idno ,password) VALUES('$firstname', '$lastname','$username', '$idno' , '$password')";
			$res = mysql_query($query);

			if ($res) {
				$errTyp = "success";
				$errMSG = "Successfully registered, you may login now";
				unset($firstname);
				unset($lastname);
				unset($username);
				unset($idno);
				unset($password);
			} else {
				$errTyp = "danger";
				$errMSG = "Something went wrong, try again later...";
			}

		}


	}
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Admin Register</title>
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"  />
<link rel="stylesheet" href="style.css" type="text/css" />
</head>
<body>

	<nav class="navbar navbar-inverse" role="navigation">
	  <div class="container-fluid">
	    <div class="navbar-header">
	        <span class="sr-only">Toggle navigation</span>
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	      <a class="navbar-brand" href="#"></a>
	    </div>

	    <!-- Collect the nav links, forms, and other content for toggling -->
	    <div class="collapse navbar-collapse" id="navbar">
	      <ul class="nav navbar-nav">
	        <li class="active"><a href="#"></span> <strong>ADIDAS</strong></a></li>
	        <li><a href="#"></a></li>
	      </ul>
	    </div><!-- /.navbar-collapse -->
	  </div><!-- /.container-fluid -->
	</nav>

<div class="container">

	<div id="login-form">
    <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" autocomplete="off">

    	<div class="col-md-12">

        	<div class="form-group">
            	<h2 class="">Sign Up</h2>
            </div>

        	<div class="form-group">
            	<hr />
            </div>

            <?php
			if ( isset($errMSG) ) {

				?>
				<div class="form-group">
            	<div class="alert alert-<?php echo ($errTyp=="success") ? "success" : $errTyp; ?>">
				<span class="glyphicon glyphicon-info-sign"></span> <?php echo $errMSG; ?>
                </div>
            	</div>
                <?php
			}
			?>
			<div class="form-group">
            	<div class="input-group">
                <span class="input-group-addon"><span class="glyphicon glyphicon-user"></span></span>
            	<input type="text" name="firstname" class="form-control" placeholder="Enter your First name" maxlength="50" value="<?php echo $firstname ?>" />
                </div>
                </div>	

            <div class="form-group">
            	<div class="input-group">
                <span class="input-group-addon"><span class="glyphicon glyphicon-user"></span></span>
            	<input type="text" name="lastname" class="form-control" placeholder="Enter Your Last name" maxlength="40" value="<?php echo $lastname ?>" />
                </div>
                </div>

             <div class="form-group">
            	<div class="input-group">
                <span class="input-group-addon"><span class="glyphicon glyphicon-user"></span></span>
            	<input type="text" name="username" class="form-control" placeholder="Enter your Username" maxlength="50" value="<?php echo $username ?>" />
                </div>
                </div>

			<div class="form-group">
            	<div class="input-group">
                <span class="input-group-addon"><span class="glyphicon glyphicon-user"></span></span>
            	<input type="number" name="idno" class="form-control" placeholder="Enter your ID Number" maxlength="50" value="<?php echo $idno ?>" />
                </div>
                </div>
			
            <div class="form-group">
            	<div class="input-group">
                <span class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></span>
            	<input type="password" name="password" class="form-control" placeholder="Enter Password" maxlength="15" />
                </div>
            </div>

            <div class="form-group">
            	<hr />
            </div>

            <div class="form-group">
            	<button type="submit" class="btn btn-block btn-primary" name="btn-signup">Register</button>
            </div>

            <div class="form-group">
            	<hr />
            </div>

            <div class="form-group">
            	<a href="index.php">Log In Here</a>
            </div>

        </div>

    </form>
    </div>

</div>

</body>
</html>
<?php ob_end_flush(); ?>
